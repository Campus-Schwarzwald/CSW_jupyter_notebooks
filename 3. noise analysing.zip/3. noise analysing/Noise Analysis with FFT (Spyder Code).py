import os
import numpy as np
import matplotlib.pyplot as plt
import librosa, librosa.display
#import IPython.display as ipd

# .wav file einlesen
BASE_FOLDER = "C:/Users/CS_Maker03/Digital 1 Vorlesung/music analysing"
pumpe_sound_file = "Pumpe.wav"
pumpe, sr = librosa.load(os.path.join(BASE_FOLDER, pumpe_sound_file))
len(pumpe)

#fft durchführen
fft1_pumpe = np.fft.fft(pumpe)
fft_abs_pumpe = np.abs(fft1_pumpe)


xf_max = len(pumpe)


# plotten des zeitdiskreten Signals
plt.plot(pumpe)
plt.title("Original Signal")
#plt.axis([0,xf_max,])
plt.tight_layout()
plt.show()


# plotten des frequenzdiskreten Signals
plt.plot(fft_abs_pumpe)
plt.title("Frequencies found")
plt.axis([0,7500, 0, 1850])
plt.tight_layout()
plt.show()


# filtern der Störfrequenzen
filtered_freq_step1 = [f if (2900 < index < 5900 and f > 1) else 0 for index, f in enumerate(fft_abs_pumpe)]
filtered_freq_complete = [0 if (3000 < index < 5800) else f for index, f in enumerate(filtered_freq_step1)]


# plotten des gefilterten frequenzdiskreten Signals
plt.plot(filtered_freq_complete)
plt.title("Gefiltertes Signal Frequenzbereich")
plt.axis([0,7500, 0, 1850])
plt.tight_layout()
plt.show()


