import cv2
from matplotlib import pyplot as plt

original = cv2.imread("t1.jpg")
duplicate = cv2.imread("t1color.jpg")


difference = cv2.subtract(original, duplicate)
b, g, r = cv2.split(difference)

fig = plt.figure()
ax1 = fig.add_subplot(1,3,1)
ax1.imshow(b)
ax2 = fig.add_subplot(1,3,2)
ax2.imshow(g)
ax3 = fig.add_subplot(1,3,3)
ax3.imshow(r)
plt.tight_layout()

