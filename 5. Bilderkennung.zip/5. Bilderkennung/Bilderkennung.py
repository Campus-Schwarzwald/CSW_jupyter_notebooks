import cv2
from matplotlib import pyplot as plt

original = cv2.imread("1.jpg")

#cv2.imshow("Original",  original)
#cv2.waitKey(0)
#cv2.destroyAllWindows()

print(original.shape)

original = cv2.imread("1.jpg")
duplicate = cv2.imread("1color.jpg")

ori_shape = original.shape[:2]
dup_shape = duplicate.shape[:2]

if ori_shape == dup_shape:
    print("Image size is same")
else: 
    print("Image is different in size")
     
difference = cv2.subtract(original, duplicate)
b, g, r = cv2.split(difference)

fig = plt.figure()
ax1 = fig.add_subplot(1,3,1)
ax1.imshow(b)
ax2 = fig.add_subplot(1,3,2)
ax2.imshow(g)
ax3 = fig.add_subplot(1,3,3)
ax3.imshow(r)
plt.tight_layout()

#if cv2.countNonZero(b) == 0 and cv2.countNonZero(g) == 0 and cv2.countNonZero(r) == 0:
#        print("The color is equal")
#else:
#        print('The color of image is different')
#        cv2.imshow('Difference', difference)
#        cv2.waitKey(0)
        
        